import os
import time

import numpy as np
from hyperopt import fmin, tpe, STATUS_OK
from keras.optimizers import RMSprop

from .hypermodel import parse_config
from ..model_building.build import build_model
from ..util.s3 import create_path, upload_s3_file
from pymongo import MongoClient

class Minimizer(object):
    '''
        An experiment determined by
            - training & testing data
            - a search space
            - a hyperopt trials object
    '''

    def __init__(self, searchId, expKey, data=None, space_config=None, trials=None):
        self.data = data
        self.space = parse_config(space_config)
        self.trials = trials
        self.expKey = expKey
        self.searchId = searchId

    def eval_model(self, model_config):
        '''
            train model on data
        '''
        import random
        model = build_model(model_config)

        from heraspy.callback import HeraCallback
        from heraspy.dispatchers.socketio_dispatcher import get_socket_dispatcher

        model_key = str(id(model_config)) + str(random.random())

        herasCallback = HeraCallback(
            model_key,
            get_socket_dispatcher('mnist', 'localhost', '4000')
        )

        model.fit(
            self.data['train']['in'],
            self.data['train']['out'],
            validation_split=0.3,
            nb_epoch=2,
            verbose=1,
            callbacks=[herasCallback],
            **(model_config['fit'])
        )

        loss = sum(model.evaluate(
            self.data['test']['in'],
            self.data['test']['out'],
            verbose=1,
        ))


        model_filename = model_key +'.h5'

        model_file_path = 'model_exports/' + model_filename
        create_path(model_file_path)
        model.save(model_file_path)

        remove_path = self.searchId + '/' + model_file_path
        upload_s3_file(model_file_path, remove_path)

        model_result = {
            'loss': loss,
            'status': STATUS_OK,
            'model_config': model_config,
            'model_file': model_filename,
            'model_key': model_key
        }

        keplr_store = get_mongo_store()
        keplr_store['experiments'].update_one({
            key: self.expKey
        }, {
            '$push': {
                'models': model_result
            }
        })

        return model_result


    def get_min_model(self, algo=tpe.suggest, max_evals=5, rseed=1234):

        return get_min_trial(
            fmin(
                self.eval_model,
                space=self.space,
                trials=self.trials,

                algo=algo,
                max_evals=max_evals,
                rseed=rseed
            ),
            self.trials
        )['result']

def get_min_trial(search_params, trials):

    for trial in trials:

        params = trial['misc']['vals']


        for key in params.keys():
            if not params[key]:
                params.pop(key, None)
            else:
                params[key] = params[key][0]

        if params == search_params:
            return trial

def get_mongo_store():

    return MongoClient(
        'mongodb://45.55.18.134:27017/keplr-store'
    )['keplr-store']
