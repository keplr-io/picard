from __future__ import print_function
from hyperopt import Trials
import numpy as np
import random

from .minimizer import Minimizer

class SparkMinimizer(object):

    def __init__(self, searchId, expKey, sc, num_workers=6):
        self.searchId = searchId
        self.expKey = expKey
        self.spark_context = sc
        self.num_workers = num_workers

    def compute_trials(self, space, data, search_config):

        return self.spark_context.parallelize(
                [i for i in range(1, 1000)]
            ).repartition(
                self.num_workers
            ).mapPartitions(
                Worker(
                    self.spark_context.broadcast(self.searchId),
                    self.spark_context.broadcast(self.expKey),
                    self.spark_context.broadcast(space),
                    self.spark_context.broadcast(data),
                    self.spark_context.broadcast(search_config)
                ).minimize
            ).collect()

    def minimize(self, space, data, search_config):
        trials_list = self.compute_trials(
            space,
            data,
            search_config
        )

        best_val = 1e7
        best_model_result = None

        for trials in trials_list:
            for trial in trials:
                val = trial.get('result').get('loss')
                if val < best_val:
                    best_val = val
                    best_model_result = trial.get('result')

        return {
            'model_file': best_model_result.get('model_file'),
            'model_config': best_model_result.get('model_config'),
            'model_key': best_model_result.get('model_key'),
            'loss': best_model_result.get('loss')
        }

class Worker(object):

    def __init__(self, searchIdBC, expKeyBC, spaceBC, dataBC, searchParamsBC):
        self.searchId = searchIdBC.value
        self.expKey = expKeyBC.value
        self.space_config = spaceBC.value
        self.data = dataBC.value
        self.search_config = searchParamsBC.value

    def minimize(self, dummy_iterator):
        trials = Trials()

        elem = dummy_iterator.next()
        random.seed(elem)
        rand_seed = np.random.randint(elem)

        minimizer = Minimizer(
            self.searchId,
            self.expKey,
            space_config=self.space_config,
            data=self.data,
            trials=trials
        )

        minimizer.get_min_model(
            rseed=rand_seed,
            **self.search_config
        )

        yield trials
