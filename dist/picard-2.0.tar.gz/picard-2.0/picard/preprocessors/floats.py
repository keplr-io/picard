def process_float(df):
    return df.as_matrix()
